Moai by ET-Huang on Thingiverse: https://www.thingiverse.com/thing:144668

Summary:
Easter Island moai